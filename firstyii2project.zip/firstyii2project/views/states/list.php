<?php

use yii\helpers\Html;
use yii\helpers\Url;
use app\models\states; # app\models\book <- nama php file dlm folder models

$this->title = 'States';
$this->params['breadcrumbs'][] = $this->title;;
$stateModel = new states; # new "book" kena same dengan nama file php dalam models jugak

$states = $stateModel->attributeLabels();
?>

<style>

table td,table th{
	text-align: center;
	padding: 5px 11px;
}

.textbold{
	font-weight: bold}
}
</style>

<ul><strong>Malaysia States</strong>
<table border = "3" cellspacing="0" cellpadding="0">
<tr>
	<TH>State Name</TH>
	<TH>Ibu Negeri</TH>
	<TH>Short Name</TH>
</tr>

<?php 
$num = 0;
$states = new states;
	foreach ($states->getStates() as $state) {
	if($states->getshorts()[$num]=="JHR"){
		$bold = "class='textbold'";
	}else{
		$bold = '';
	}
?>

<tr <?php echo $bold;?>> 
	<td><?php echo $state;?></td>
	<td><?php echo $states->getibus()[$num];?></td>
	<td><?php echo $states->getshorts()[$num];?></td>
</tr>
<?php 
$num++;
}?>
</table></ul>
<hr/>
<ul>*<b>Bold </b> state is the state you're living in.</ul>
