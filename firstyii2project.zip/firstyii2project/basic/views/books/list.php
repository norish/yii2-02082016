<?php

use yii\helpers\Html;
use yii\helpers\Url;
use app\models\book; # app\models\book <- nama php file dlm folder models

$this->title = 'Book';
$this->params['breadcrumbs'][] = $this->title;;
$bookModel = new book; # new "book" kena same dengan nama file php dalam models jugak

$books = $bookModel->attributeLabels();
?>
<div class="site-list">
   <ul>
       <li><?php echo $books['bookname']; ?></li>
       <li><?php echo $books['publisher']; ?></li>
       <li><?php echo $books['edition']; ?></li>
       <li><?php echo $books['author']; ?></li>
       <li><?php echo $books['price']; ?></li>
   </ul>
</div>
