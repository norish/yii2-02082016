<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=127.0.0.1;dbname=norish',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
